import './App.css';
import ColoredUserpic from './coloredUserpic';

function App() {
  return (
    <div >

<ColoredUserpic
/>
    </div>
  );
}

export default App;
