import React from 'react';
import './App.css'

const ColoredUserpic = () => {
    return (<div >
        <div className="border-wrap">
            <img className='img' src='https://media.macphun.com/img/uploads/customer/how-to/579/15531840725c93b5489d84e9.43781620.jpg?q=85&w=1340' />
            </div>
            </div>)
}
export default ColoredUserpic
